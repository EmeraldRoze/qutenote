# QuteNote app screens

Every app screen except Home, exported from the QuteNote App Screens board. Home is in the separate **QuteNote-Home** folder; keep both folders side by side and the Home links will work.

## Folders

```
QuteNote-App-Screens/
  index.html          Open this first: every screen as a thumbnail, grouped by flow
  README.md
  html/               One working HTML file per screen (opens offline in any browser)
  png/                Each screen at iPhone size, 1170 x 2532 (@3x)
                      Tall screens also have a -full@3x.png showing the whole scroll
  assets/images/      Logo, paper-collage emoji, postmark heart layers, artist cards
  assets/fonts/       Unbounded, Anonymous Pro (regular, bold, italic), Caveat
```

## Screens

| # | Screen | HTML | PNG |
| --- | --- | --- | --- |
| 01 | Splash | `html/01-splash.html` | `png/01-splash@3x.png` |
| 02 | Sign up | `html/02-sign-up.html` | `png/02-sign-up@3x.png` |
| 03 | Pick your first QTs | `html/03-pick-your-first-qts.html` | `png/03-pick-your-first-qts@3x.png` |
| 04 | Birthdays | `html/04-birthdays.html` | `png/04-birthdays@3x.png` |
| 05 | Reminders | `html/05-reminders.html` | `png/05-reminders@3x.png` |
| 06 | Choose a card | `html/06-choose-a-card.html` | `png/06-choose-a-card@3x.png` + `png/06-choose-a-card-full@3x.png` |
| 07 | Write your note | `html/07-write-your-note.html` | `png/07-write-your-note@3x.png` |
| 08 | Ready to send | `html/08-ready-to-send.html` | `png/08-ready-to-send@3x.png` |
| 09 | Sent | `html/09-sent.html` | `png/09-sent@3x.png` |
| 10 | Profile | `html/10-profile.html` | `png/10-profile@3x.png` + `png/10-profile-full@3x.png` |
| 11 | QTs | `html/11-qts.html` | `png/11-qts@3x.png` |
| 12 | Dates | `html/12-dates.html` | `png/12-dates@3x.png` |
| 13 | Invite | `html/13-invite.html` | `png/13-invite@3x.png` |
| 14 | Handwriting intro | `html/14-handwriting-intro.html` | `png/14-handwriting-intro@3x.png` |
| 15 | Handwriting write a line | `html/15-handwriting-write-a-line.html` | `png/15-handwriting-write-a-line@3x.png` |
| 16 | Handwriting done | `html/16-handwriting-done.html` | `png/16-handwriting-done@3x.png` |
| 17 | Recipient text | `html/17-recipient-text.html` | `png/17-recipient-text@3x.png` |
| 18 | Recipient claim | `html/18-recipient-claim.html` | `png/18-recipient-claim@3x.png` |
| 19 | Recipient done | `html/19-recipient-done.html` | `png/19-recipient-done@3x.png` |
| 20 | Anonymous heads-up | `html/20-anonymous-heads-up.html` | `png/20-anonymous-heads-up@3x.png` |
| 21 | QR say thanks | `html/21-qr-say-thanks.html` | `png/21-qr-say-thanks@3x.png` |
| 22 | V2 Group card start | `html/22-v2-group-card-start.html` | `png/22-v2-group-card-start@3x.png` |
| 23 | V2 Group card organizer | `html/23-v2-group-card-organizer.html` | `png/23-v2-group-card-organizer@3x.png` + `png/23-v2-group-card-organizer-full@3x.png` |
| 24 | V2 Group card signer | `html/24-v2-group-card-signer.html` | `png/24-v2-group-card-signer@3x.png` |

## Good to know

- Each screen is shown in its starting state: menus closed, the first card selected, default toggles. The HTML files link to each other, so you can click through the flow in a browser.
- Fonts and images load from the `assets` folder, so keep the folder structure as it is.
- Caveat is only a stand-in for a person's own handwriting on Write your note and the handwriting screens.
- Screens 22 to 24 are group cards, parked for V2.
- Brand rules (colors, fonts, buttons, lime and candy-neon use) are in the QuteNote iOS Design Guide.
